
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;

import javax.mail.*;
import javax.mail.internet.*;


import java.awt.Choice;
import java.awt.Graphics2D;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.swing.table.DefaultTableModel;
import org.json.JSONObject;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Abhi
 */
public class DaktarHere extends javax.swing.JFrame {

    /**
     * Creates new form DaktarHere
     */
             
    // Create choice
    Choice c=new Choice();
    DefaultTableModel dm,dm2; 
    // Create label

    
    public DaktarHere() {
        initComponents();
         
        createColoumns();
        createColoumns2();
   
   
    // Add choice
    }

    private void createColoumns()
    {
        dm = (DefaultTableModel)jTable1.getModel();
        dm.addColumn("Medicine Name");
        dm.addColumn("Qty_Per_Dose");
        dm.addColumn("Number of Days");
        dm.addColumn("Days of Medication");
        dm.addColumn("Time of Medication");
        dm.addColumn("Comments");
    }
    
    private void createColoumns2()
    {
        dm2 = (DefaultTableModel)jTable2.getModel();
        dm2.addColumn("Test Name");
        dm2.addColumn("Comments");
    }
    private void populateData2()
    {
        String testname = jTextField10.getText();
        jTextField10.setText("");
        
        String Comments = jTextArea1.getText();
        jTextArea1.setText("");
        
        String[] vals = {testname, Comments};
        dm2.addRow(vals);
    }
    private void populateData()
    {
        String medName = jTextField7.getText();
        jTextField7.setText("");
        String qty = jTextField6.getText();
        jTextField6.setText("");
        String No_Day = jTextField8.getText();
        jTextField8.setText("");
        
        String days = new String();
        days = "";
        if (jCheckBox5.isSelected())
        {
            days = jCheckBox5.getText();
        }
        else
        {
            if(jCheckBox6.isSelected())
            {
                days = jCheckBox6.getText();
            }
            if(jCheckBox7.isSelected())
            {
                if(days == "")
                {
                    days = jCheckBox7.getText();
                }
                else
                {
                    days = days+ ','+jCheckBox7.getText();
                }
                
            }
            if(jCheckBox8.isSelected())
            {
                if(days == "")
                {
                    days = jCheckBox8.getText();
                }
                else
                {
                    days = days+ ','+jCheckBox8.getText();
                }
            }
            if (jCheckBox9.isSelected())
            {
                if(days == "")
                {
                    days = jCheckBox9.getText();
                }
                else
                {
                    days = days+ ','+jCheckBox9.getText();
                }
            }
            if (jCheckBox10.isSelected())
            {
               if(days == "")
                {
                    days = jCheckBox10.getText();
                }
                else
                {
                    days = days+ ','+jCheckBox10.getText();
                }
            }
             if (jCheckBox11.isSelected())
            {
                if(days == "")
                {
                    days = jCheckBox11.getText();
                }
                else
                {
                    days = days+ ','+jCheckBox11.getText();
                }
            }
              if (jCheckBox12.isSelected())
            {
                if(days == "")
                {
                    days = jCheckBox12.getText();
                }
                else
                {
                    days = days+ ','+jCheckBox12.getText();
                }
            }
            if(!jCheckBox5.isSelected())
            {
                jCheckBox5.doClick();
            }
        }
        
        String timing = new String();
        timing = "";
        if(jCheckBox1.isSelected())
        {
            timing = jCheckBox1.getText();
        }
        if(jCheckBox2.isSelected())
        {
            if(timing == "")
            {
                timing = jCheckBox2.getText();
            }
            else
            {
                timing = timing + ", "+jCheckBox2.getText();
            }
        }
         if(jCheckBox3.isSelected())
        {
            if(timing == "")
            {
                timing = jCheckBox3.getText();
            }
            else
            {
                timing = timing + ", "+jCheckBox3.getText();
            }
        }
        if(jCheckBox4.isSelected())
        {
            if(timing == "")
            {
                timing = jCheckBox4.getText();
            }
            else
            {
                timing = timing + ", "+jCheckBox4.getText();
            }
        }
        
        jCheckBox1.setSelected(false);
        jCheckBox2.setSelected(false);
        jCheckBox3.setSelected(false);
        jCheckBox4.setSelected(false);
        
        String comments = jTextField9.getText();
        jTextField9.setText("");
        
        String[] vals =  {medName,qty,No_Day,days,timing,comments};
        dm.addRow(vals);
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jLabel5 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jCheckBox4 = new javax.swing.JCheckBox();
        jTextField6 = new javax.swing.JTextField();
        jCheckBox5 = new javax.swing.JCheckBox();
        jCheckBox6 = new javax.swing.JCheckBox();
        jCheckBox7 = new javax.swing.JCheckBox();
        jCheckBox8 = new javax.swing.JCheckBox();
        jCheckBox9 = new javax.swing.JCheckBox();
        jCheckBox10 = new javax.swing.JCheckBox();
        jCheckBox11 = new javax.swing.JCheckBox();
        jCheckBox12 = new javax.swing.JCheckBox();
        jButton1 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jTextField10 = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("Dr. S Tripathy");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, 104, -1));

        jLabel2.setText("Patient's Name");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 43, 82, 22));

        jTextField1.setText("Pranjal Singh");
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 44, 107, -1));

        jLabel3.setText("Age");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 74, -1, -1));

        jTextField2.setText("23");
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 71, 107, -1));

        jLabel4.setText("Sex");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 97, -1, -1));

        jRadioButton1.setSelected(true);
        jRadioButton1.setText("Male");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jRadioButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 97, -1, -1));

        jRadioButton2.setText("Female");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jRadioButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(145, 97, -1, -1));

        jLabel5.setText("Contact Number:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 40, 88, 22));

        jTextField3.setText("8953981856");
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 40, 114, -1));

        jLabel6.setText("Email Id");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 70, 68, -1));

        jTextField4.setText("pranjals16@gmail.com");
        getContentPane().add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 70, 114, -1));

        jTextField5.setText("20/03/2016");
        getContentPane().add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 100, 114, -1));

        jLabel7.setText("Date");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 100, 57, -1));

        jPanel1.setLayout(new java.awt.BorderLayout());
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 138, -1, -1));

        jPanel2.setBackground(new java.awt.Color(204, 255, 255));

        jLabel10.setText("Medicine Name");

        jLabel11.setText("Dosage");

        jTextField7.setText("Roxithromycin");
        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });

        jTextField8.setText("2");

        jLabel13.setText("Comments");

        jTextField9.setText("Nill");
        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });

        jCheckBox1.setSelected(true);
        jCheckBox1.setText("M");

        jCheckBox2.setText("No");
        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        jCheckBox3.setSelected(true);
        jCheckBox3.setText("E");

        jCheckBox4.setText("Ni");

        jTextField6.setText("1");

        jCheckBox5.setSelected(true);
        jCheckBox5.setText("Daily");
        jCheckBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox5ActionPerformed(evt);
            }
        });

        jCheckBox6.setSelected(true);
        jCheckBox6.setText("Sun");
        jCheckBox6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox6ActionPerformed(evt);
            }
        });

        jCheckBox7.setSelected(true);
        jCheckBox7.setText("Mon");
        jCheckBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox7ActionPerformed(evt);
            }
        });

        jCheckBox8.setSelected(true);
        jCheckBox8.setText("Tue");
        jCheckBox8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox8ActionPerformed(evt);
            }
        });

        jCheckBox9.setSelected(true);
        jCheckBox9.setText("Wed");
        jCheckBox9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox9ActionPerformed(evt);
            }
        });

        jCheckBox10.setSelected(true);
        jCheckBox10.setText("Thu");
        jCheckBox10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox10ActionPerformed(evt);
            }
        });

        jCheckBox11.setSelected(true);
        jCheckBox11.setText("Fri");
        jCheckBox11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox11ActionPerformed(evt);
            }
        });

        jCheckBox12.setSelected(true);
        jCheckBox12.setText("Sat");
        jCheckBox12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox12ActionPerformed(evt);
            }
        });

        jButton1.setText("ADD MEDICINE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel9.setText("Qty");

        jLabel12.setText("No. Of Days");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jCheckBox1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox4))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jCheckBox9)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jCheckBox10)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jCheckBox11)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jCheckBox12))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                            .addComponent(jCheckBox5)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jCheckBox6)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jCheckBox7)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jCheckBox8)))
                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(jButton1)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))
                        .addGap(29, 29, 29)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField8)
                            .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(88, 88, 88)
                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11)
                .addGap(4, 4, 4)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox5)
                    .addComponent(jCheckBox6)
                    .addComponent(jCheckBox7)
                    .addComponent(jCheckBox8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox9)
                    .addComponent(jCheckBox10)
                    .addComponent(jCheckBox11)
                    .addComponent(jCheckBox12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox1)
                    .addComponent(jCheckBox2)
                    .addComponent(jCheckBox3)
                    .addComponent(jCheckBox4))
                .addGap(34, 34, 34)
                .addComponent(jLabel13)
                .addGap(18, 18, 18)
                .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel16)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap(60, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, -10, 310, 410));

        jPanel3.setBackground(new java.awt.Color(171, 171, 227));

        jLabel8.setBackground(new java.awt.Color(102, 153, 255));
        jLabel8.setFont(new java.awt.Font("Tekton Pro", 0, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 0, 51));
        jLabel8.setText("    Prescription");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jTable2.setBackground(new java.awt.Color(153, 153, 153));
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(jTable2);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(466, 466, 466)
                        .addComponent(jLabel8))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 475, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 163, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 480, 430));

        jPanel5.setBackground(new java.awt.Color(204, 255, 204));

        jTextField10.setText("Blood Test");

        jLabel14.setText("Test Name");

        jLabel15.setText("Comments");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        jButton2.setText("ADD TEST");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2))
                .addGap(0, 116, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 400, 310, 190));

        jButton3.setText("SUBMIT & MAIL");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 630, 230, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        // TODO add your handling code here:
        if(jRadioButton2.isSelected() && jRadioButton1.isSelected())
        {
            jRadioButton2.setSelected(false);
        }
        else if((!jRadioButton2.isSelected()) && (!jRadioButton1.isSelected()))
        {
            jRadioButton2.setSelected(true);
        }
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField9ActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jCheckBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox5ActionPerformed
        // TODO add your handling code here:
        if (jCheckBox5.isSelected())
        {
            jCheckBox6.setSelected(true);
            jCheckBox7.setSelected(true);
            jCheckBox8.setSelected(true);
            jCheckBox9.setSelected(true);
            jCheckBox10.setSelected(true);
            jCheckBox11.setSelected(true);
            jCheckBox12.setSelected(true);
        }
        else
        {
            jCheckBox6.setSelected(false);
            jCheckBox7.setSelected(false);
            jCheckBox8.setSelected(false);
            jCheckBox9.setSelected(false);
            jCheckBox10.setSelected(false);
            jCheckBox11.setSelected(false);
            jCheckBox12.setSelected(false);
        }
        
        
    }//GEN-LAST:event_jCheckBox5ActionPerformed

    private void jCheckBox6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox6ActionPerformed
        // TODO add your handling code here:
       
        if(jCheckBox6.isSelected() & jCheckBox7.isSelected() & jCheckBox8.isSelected() && jCheckBox9.isSelected() & jCheckBox10.isSelected() &  jCheckBox11.isSelected() & jCheckBox12.isSelected())
        {
           jCheckBox5.setSelected(true);
        }
        else
        {
            jCheckBox5.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox6ActionPerformed

    private void jCheckBox7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox7ActionPerformed
        // TODO add your handling code here:
          if(jCheckBox6.isSelected() & jCheckBox7.isSelected() & jCheckBox8.isSelected() && jCheckBox9.isSelected() & jCheckBox10.isSelected() &  jCheckBox11.isSelected() & jCheckBox12.isSelected())
        {
           jCheckBox5.setSelected(true);
        }
        else
        {
            jCheckBox5.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox7ActionPerformed

    private void jCheckBox8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox8ActionPerformed
        // TODO add your handling code here:
         if(jCheckBox6.isSelected() & jCheckBox7.isSelected() & jCheckBox8.isSelected() && jCheckBox9.isSelected() & jCheckBox10.isSelected() &  jCheckBox11.isSelected() & jCheckBox12.isSelected())
        {
           jCheckBox5.setSelected(true);
        }
        else
        {
            jCheckBox5.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox8ActionPerformed

    private void jCheckBox9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox9ActionPerformed
        // TODO add your handling code here:
         if(jCheckBox6.isSelected() & jCheckBox7.isSelected() & jCheckBox8.isSelected() && jCheckBox9.isSelected() & jCheckBox10.isSelected() &  jCheckBox11.isSelected() & jCheckBox12.isSelected())
        {
           jCheckBox5.setSelected(true);
        }
        else
        {
            jCheckBox5.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox9ActionPerformed

    private void jCheckBox10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox10ActionPerformed
        // TODO add your handling code here:
         if(jCheckBox6.isSelected() & jCheckBox7.isSelected() & jCheckBox8.isSelected() && jCheckBox9.isSelected() & jCheckBox10.isSelected() &  jCheckBox11.isSelected() & jCheckBox12.isSelected())
        {
           jCheckBox5.setSelected(true);
        }
        else
        {
            jCheckBox5.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox10ActionPerformed

    private void jCheckBox11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox11ActionPerformed
        // TODO add your handling code here:
         if(jCheckBox6.isSelected() & jCheckBox7.isSelected() & jCheckBox8.isSelected() && jCheckBox9.isSelected() & jCheckBox10.isSelected() &  jCheckBox11.isSelected() & jCheckBox12.isSelected())
        {
           jCheckBox5.setSelected(true);
        }
        else
        {
            jCheckBox5.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox11ActionPerformed

    private void jCheckBox12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox12ActionPerformed
        // TODO add your handling code here:
         if(jCheckBox6.isSelected() & jCheckBox7.isSelected() & jCheckBox8.isSelected() && jCheckBox9.isSelected() & jCheckBox10.isSelected() &  jCheckBox11.isSelected() & jCheckBox12.isSelected())
        {
           jCheckBox5.setSelected(true);
        }
        else
        {
            jCheckBox5.setSelected(false);
        }
    }//GEN-LAST:event_jCheckBox12ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
       populateData();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        populateData2();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        ArrayList<ArrayList<String>> prescription_info = new ArrayList<ArrayList<String>>();
        
        for (int count = 0 ; count<dm.getRowCount(); count++)
        {
            ArrayList<String> values =  new ArrayList<String>();
            for(int j = 0;j < dm.getColumnCount(); j++)
            {
                values.add(dm.getValueAt(count, j).toString());
            }
            prescription_info.add(values);
        }
        
        System.out.println(prescription_info);
        //System.out.println(prescription_info.get(0).get(3));
        
        ArrayList<ArrayList<String>> test_info = new ArrayList<ArrayList<String>>();
        
        for (int count = 0 ; count<dm2.getRowCount(); count++)
        {
            ArrayList<String> values =  new ArrayList<String>();
            for(int j = 0;j < dm2.getColumnCount(); j++)
            {
                values.add(dm2.getValueAt(count, j).toString());
            }
            test_info.add(values);
        }
        
        String patient_name  =  jTextField1.getText();
        System.out.println(test_info);
        String dr_name = "Dr. S Tripathy";
        String sex;
        if(jRadioButton1.isSelected())
        {
            sex = "Male";
        }
        else
        {
             sex = "Female";
        }
        String age = jTextField2.getText();
        String p_contacts = jTextField3.getText();
        String email = jTextField4.getText();
        String date = jTextField5.getText();
        
        
        Font bfBold12 = new Font(FontFamily.TIMES_ROMAN, 12, Font.BOLD, new BaseColor(0, 0, 0)); 
        Font bf12 = new Font(FontFamily.TIMES_ROMAN, 12);
        Document prescribe = new Document();
        FileOutputStream fls =  null;
        String pdffile = "";
        String textfile = "";
        try {
            fls =  new FileOutputStream(patient_name+"prescription.pdf");
            pdffile = patient_name+"prescription.pdf";
            textfile = patient_name+"prescription.txt";
        } catch (Exception ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }

        PdfWriter writer = null;
        try {
            writer = PdfWriter.getInstance(prescribe, fls);
        } catch (Exception e) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, e);
        }

        prescribe.open();
        try {
            prescribe.add(new Paragraph("Auto Generated Prescription"));
        } catch (DocumentException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            prescribe.add(new Paragraph("Prescribed By: "+dr_name));
        } catch (DocumentException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            prescribe.add(new Paragraph("Date: "+date));
        } catch (DocumentException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }
             try {
            prescribe.add(new Paragraph("\n----------------------------------------------------------------------------------------------------------------------------------"));
            prescribe.add(new Paragraph("Patient Info"));
        } catch (DocumentException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }
        
             try {
            prescribe.add(new Paragraph("Name: "+patient_name));
        } catch (DocumentException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }
                   try {
            prescribe.add(new Paragraph("Age: "+age));
        } catch (DocumentException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }
                     try {
            prescribe.add(new Paragraph("Sex: "+sex));
        } catch (DocumentException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        } 
                    try {
            prescribe.add(new Paragraph("Contacts: "+p_contacts));
        } catch (DocumentException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }
                      try {
            prescribe.add(new Paragraph("Email Id: "+email));
        } catch (DocumentException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }
                      
       try {
            prescribe.add(new Paragraph("\n----------------------------------------------------------------------------------------------------------------------------------"));
            prescribe.add(new Paragraph("Prescriptions\n"));
        } catch (DocumentException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PdfContentByte cb = writer.getDirectContent();
        PdfTemplate tp = cb.createTemplate(900, 900);
        Graphics2D g2 ;
        float[] columnWidths = {4f, 2f, 2f, 4f, 2f, 2f};
        PdfPTable table = new PdfPTable(columnWidths);
        table.setWidthPercentage(100f);
        //insert column headings
        insertCell(table, "Med Name", Element.ALIGN_CENTER, 1, bfBold12);
        insertCell(table, "Qty Per Day", Element.ALIGN_CENTER, 1, bfBold12);
        insertCell(table, "No of Days", Element.ALIGN_CENTER, 1, bfBold12);
        insertCell(table, "Days of Med", Element.ALIGN_CENTER, 1, bfBold12);
        insertCell(table, "Time of Med", Element.ALIGN_CENTER, 1, bfBold12);
        insertCell(table, "Comments", Element.ALIGN_CENTER, 1, bfBold12);
        table.setHeaderRows(1);
        //insert an empty row
        insertCell(table, "", Element.ALIGN_CENTER, 6, bfBold12);
        
        //data to fill
        for (int i=0; i<prescription_info.size(); i++)
        {
            List<String> temp_list =prescription_info.get(i);
            for (int j=0; j<temp_list.size(); j++)
            {
                insertCell(table, temp_list.get(j), Element.ALIGN_CENTER, 1, bf12);
            }
        }
        System.out.print(table.getBody().toString());
        //add the PDF table to the paragraph 
        Paragraph para= new Paragraph();
        para.add(table);
        try {
            prescribe.add(para);
        } catch (DocumentException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        try {
            prescribe.add(new Paragraph("\n----------------------------------------------------------------------------------------------------------------------------------"));
            prescribe.add(new Paragraph("Tests\n"));
        } catch (DocumentException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PdfContentByte cb1 = writer.getDirectContent();
        PdfTemplate tp1 = cb1.createTemplate(900, 900);
        Graphics2D g21 ;
        float[] columnWidths1 = {4f, 3f};
        PdfPTable table1 = new PdfPTable(columnWidths1);
        table1.setWidthPercentage(100f);
        //insert column headings
        insertCell(table1, "Test Name", Element.ALIGN_CENTER, 1, bfBold12);
        insertCell(table1, "Description/Comment", Element.ALIGN_CENTER, 1, bfBold12);
        table.setHeaderRows(1);
        //insert an empty row
        insertCell(table1, "", Element.ALIGN_CENTER, 2, bfBold12);
        
        //data to fill
        for (int i=0; i<test_info.size(); i++)
        {
            List<String> temp_list = test_info.get(i);
            for (int j=0; j<temp_list.size(); j++)
            {
                insertCell(table1, temp_list.get(j), Element.ALIGN_CENTER, 1, bf12);
            }
        }
        System.out.print(table1.getBody().toString());
        //add the PDF table to the paragraph 
        Paragraph para1= new Paragraph();
        para1.add(table1);
        try {
            prescribe.add(para1);
        } catch (DocumentException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }


        /*g2 = tp.createGraphics(900, 900);
        String colname = "";
        for(int i = 0;i<dm.getColumnCount(); i++)
        {
            colname+=dm.getColumnName(i)+"|";
        }
        try {
            prescribe.add(new Paragraph(colname));
        } catch (DocumentException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }
        jTable1.print(g2);
        jTable2.print(g2);

        g2.dispose();*/
        cb.addTemplate(tp, 30, 300);
        prescribe.close();
        System.out.println("PDF Creation Complete");
        try
        {
            createTextFile(prescription_info, textfile, date);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        
        int a = dm.getRowCount();
        for (int i=a; i>0; i--)
        {
            dm.removeRow(i-1);
        }
        
        int b = dm2.getRowCount();
        for (int i=b; i>0; i--)
        {
            dm2.removeRow(i-1);
        }
        
        
        System.out.println(textfile+"  ------------  "+ pdffile);
        mail_to_patient(email,pdffile,textfile,"Prescription By Dr. Tripathy");
        
    }//GEN-LAST:event_jButton3ActionPerformed

    /*private void createJson(ArrayList<ArrayList<String>> prescription, String id, String date)
    {
        int n = prescription.size();
        String table_st = "{";
        for (int i=0; i<n; i++)
        {
            table_st = "\"" + i + "\":{}"
        }
        String json_st = "date:" + date +", \"number_of_medicines\":" + n + ", \"medicines\":" +  +"}";
    }*/
    
    private void createTextFile(ArrayList<ArrayList<String>> prescription, String id, String date) throws IOException
    {
        String temp_st = "";
        for (int i=0; i<prescription.size(); i++)
        {
            ArrayList<String> temp_list = prescription.get(i);
            int j;
            for (j=0; j<temp_list.size()-1; j++)
            {
                temp_st += temp_list.get(j).toString() + "; ";
            }
            temp_st += temp_list.get(j).toString() + "\n";
        }
        
        PrintWriter out;
        try {
            File file = new File(id);
            //out.println(temp_st);
            if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(temp_st);
			bw.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void insertCell(PdfPTable table, String text, int align, int colspan, Font font){
  
  //create a new cell with the specified Text and Font
  PdfPCell cell = new PdfPCell(new Phrase(text.trim(), font));
  //set the cell alignment
  cell.setHorizontalAlignment(align);
  //set the cell column span in case you want to merge two or more cells
  cell.setColspan(colspan);
  //in case there is no text and you wan to create an empty row
  if(text.trim().equalsIgnoreCase("")){
   cell.setMinimumHeight(10f);
  }
  //add the call to the table
  table.addCell(cell);
  jTextField1.setText("");
  jTextField2.setText("");
  jTextField3.setText("");
  jTextField4.setText("");
  jRadioButton1.setSelected(false);
  jRadioButton2.setSelected(false);
  
 }
    private void mail_to_patient(String toMailId, String fn1, String fn2, String subject)
    {
        MailingAttachment ma1 = new MailingAttachment();
        try {
            ma1.sendMail(toMailId, fn1, fn2, subject);
        } catch (MessagingException ex) {
            Logger.getLogger(DaktarHere.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
        // TODO add your handling code here:
        if(jRadioButton2.isSelected() && jRadioButton1.isSelected())
        {
            jRadioButton1.setSelected(false);
        }
        else if((!jRadioButton2.isSelected()) && (!jRadioButton1.isSelected()))
        {
            jRadioButton2.setSelected(true);
        }
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DaktarHere.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DaktarHere.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DaktarHere.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DaktarHere.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DaktarHere().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox10;
    private javax.swing.JCheckBox jCheckBox11;
    private javax.swing.JCheckBox jCheckBox12;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JCheckBox jCheckBox7;
    private javax.swing.JCheckBox jCheckBox8;
    private javax.swing.JCheckBox jCheckBox9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}


class MailingAttachment {
    
private void addAttachment(Multipart multipart,String path, String filename) throws MessagingException
{
    try{
        DataSource source = new FileDataSource(path);
        BodyPart messageBodyPart = new MimeBodyPart();
        messageBodyPart.setText("Here's the file");
        messageBodyPart.setDataHandler(new DataHandler(source));
        messageBodyPart.setFileName(filename);
        multipart.addBodyPart(messageBodyPart);
    }catch (MessagingException me) {
        System.out.println(me);
    }
}

public void sendMail(String toMailId, String fn1, String fn2, String subject) throws MessagingException {
    String host = "smtp.gmail.com";
    String from = "ratb4u@gmail.com";
    String pass = "9433154747";
    Properties props = System.getProperties();
    props.put("mail.smtp.starttls.enable", "true"); // added this line
    props.put("mail.smtp.host", host);
    props.put("mail.smtp.user", from);
    props.put("mail.smtp.password", pass);
    props.put("mail.smtp.port", "587");
    props.put("mail.smtp.auth", "true");

    String[] to = {toMailId}; // added this line

    Session session = Session.getDefaultInstance(props, null);
    MimeMessage message = new MimeMessage(session);
    message.setFrom(new InternetAddress(from));

    InternetAddress[] toAddress = new InternetAddress[to.length];

    // To get the array of addresses
    for( int i=0; i < to.length; i++ ) { // changed from a while loop
        toAddress[i] = new InternetAddress(to[i]);
    }
    System.out.println(Message.RecipientType.TO);

    for( int i=0; i < toAddress.length; i++) { // changed from a while loop
        message.addRecipient(Message.RecipientType.TO, toAddress[i]);
    }
    message.setSubject(subject);
    
    //System.out.println("message.setText done");
    Multipart multipart = new MimeMultipart();
    //System.out.println("calling addAttachment");
    
    addAttachment(multipart,"C:/Users/Abhi/Desktop/DaktarApp/Daktar/"+fn1,fn1);
    addAttachment(multipart,"C:/Users/Abhi/Desktop/DaktarApp/Daktar/"+fn2,fn2);
    
    addAttachment(multipart,"C:/Users/Abhi/Desktop/DaktarApp/Daktar/qrcode.jpeg","QrCodeForPayment.jpg");
          
    //System.out.println("Attachment added");
    
    message.setContent(multipart);
    //System.out.println("message content set to multipart");
    
    Transport transport = session.getTransport("smtp");
    transport.connect(host, from, pass);
    transport.sendMessage(message, message.getAllRecipients());
    transport.close();
  }
}